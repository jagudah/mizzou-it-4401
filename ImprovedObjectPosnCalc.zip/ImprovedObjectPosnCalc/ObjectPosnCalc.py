print('Welcome to the Object Final Position Calculation Program!')

do_Calculation = True

while(do_Calculation):
    while(True): #Error Handling for initial position variable
        try:
            x_initial = float(input("Please enter a number for initial position: "))
        except ValueError:
            print("Your input was invalid. Only numerical values are allowed")
        else:
            break

    while(True): #Error Handling for initial velocity variable
        try:
            v_initial = float(input("Please enter a number for initial velocity: "))
        except ValueError:
            print("Your input was invalid. Only numerical values are allowed.")
        else:
            break

    while(True): #Error Handling for acceleration variable
        try:
            a = float(input("Please enter a number for acceleration: "))
        except ValueError:
            print("Your input was invalid. Only numerical values are allowed.")
        else:
            break

    while(True): #Error Handling for time variable
        try:
            t = float(input("Please enter a non-negative number for time: "))
            if (t < 0):
                print('Negative elapsed time is not allowed. Only non-negative values are allowed.')
                continue
        except ValueError:
            print("The value you entered is invalid. Only numerical values are allowed.")
        else:
            break

    x_final = (x_initial + (v_initial * t) + (0.5 * a * (t**2)))

    print('The final position of the object is %3.2f meters' % x_final)

    another_Calculation = input("Would you like to perform another calculation? (y/n): ")
    if (another_Calculation != "y"):
        do_Calculation = False
        print('Thank you for using the Object Final Position Calculation Program!')