import random, pickle, io, os

stats = {
    "Name": '',
    "Wins": 0,
    "Losses": 0,
    "Ties": 0,
    "Win/Loss Ratio": 0
}

def gameplay(round_Number):
    print("Round %d\n" %round_Number)
    print("1. Rock\n2. Paper\n3. Scissors\n")
    user = input("What will it be? ")
    bot = random.randint(1,3)

    if(user == '1' and bot == 1):
        print("You chose Rock. The computer chose Rock. It's a tie!")
        stats["Ties"] += 1
    elif(user == '1' and bot == 2):
        print("You chose Rock. The computer chose Paper. You lose!")
        stats["Losses"] += 1
    elif(user == '1' and bot == 3):
        print("You chose Rock. The computer chose Scissors. You win!")
        stats["Wins"] += 1
    elif(user == '2' and bot == 1):
        print("You chose Paper. The computer chose Rock. You win!")
        stats["Wins"] += 1
    elif(user == '2' and bot == 2):
        print("You chose Paper. The computer chose Paper. It's a tie!")
        stats["Ties"] += 1
    elif(user == '2' and bot == 3):
        print("You chose Paper. The computer chose Scissors. You lose!")
        stats["Losses"] += 1
    elif(user == '3' and bot == 1):
        print("You chose Scissors. The computer chose Rock. You lose!")
        stats["Losses"] += 1
    elif(user == '3' and bot == 2):
        print("You chose Scissors. The computer chose Paper. You win!")
        stats["Wins"] += 1
    elif(user == '3' and bot == 3):
        print("You chose Scissors. The computer chose Scissors. It's a tie!")
        stats["Ties"] += 1
    else:
        raise ValueError("Invalid input. Please enter a number between 1 and 3.")

    if(stats["Wins"] >= 0 and stats["Losses"] == 0):
        stats.update({"Win/Loss Ratio": 0})
    else:
        win_loss = float(stats["Wins"] / stats["Losses"])
        stats.update({"Win/Loss Ratio": win_loss})

def post_selection(x):
    do_Game = True
    while(do_Game):
        print("What would you like to do?\n")
        print("1. Play Again\n2. View Statistics\n3. Quit\n")
        post_game = input("Enter choice: ")

        if(post_game == '1'):
            x += 1
            gameplay(x)

        elif(post_game == '2'):
            print("%s, here are your game play statistics..." %name)
            print("Wins: %d" %stats["Wins"])
            print("Losses: %d" %stats["Losses"])
            print("Ties: %d" %stats["Ties"])
            print("Win/Loss Ratio: %.2f\n" %stats["Win/Loss Ratio"])
            
        elif(post_game == '3'):
            file = open(name + ".rps", "wb")
            if file:
                pickle.dump(stats, file)
                file.close()
                print("%s, your game has been saved.\n" %name)
                do_Game = False
            else:
                print("Sorry %s, the game could not be saved." %name)

        else:
            raise ValueError("Invalid input. Please choose a number between 1 and 3.")

do_Game = True
print("Welcome to Rock, Paper, Scissors!\n")
while(do_Game):
    try:
        print("1. Start New Game\n2. Load Game\n3. Quit\n")
        pre_game = input("Enter choice: ")
        x = stats["Wins"] + stats["Losses"] + stats["Ties"] + 1
        if(pre_game == '1'):
            name = input("What is your name? ")
            stats.update({"Name": name})
            print("Hello %s. Let's play!" %name)
            gameplay(x)
            file = open(name + ".rps", "wb")
            pickle.dump(stats, file)
            file.close()
            post_selection(x)
            
        elif(pre_game == '2'):
            name = input("What is your name? ")
            file = open(name +".rps", "rb")
            if file:
                stats = pickle.load(file)
                file.close()
                print("Welcome back %s. Let's play!\n" %name)
                x = stats["Wins"] + stats["Losses"] + stats["Ties"] + 1
                gameplay(x)
                post_selection(x)
            else:
                print("1. Start New Game\n2. Load Game\n3. Quit\n")
                pre_game = input("Enter choice: ")

        elif(pre_game == '3'):
            print("Goodbye!")
            do_Game = False

        else:
            raise ValueError("Invalid input. Please choose a number between 1 and 3.")
        break

    except Exception as err:
        print(name + ", your game could not be found.")
        print(err)