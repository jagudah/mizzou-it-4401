do_Estimation = True
while(do_Estimation):
    print("Welcome to the Paint Job Estimator Program!")
    while(True): #Error Handling for Wall Space to be painted
        try:
            user_PaintArea = float(input("Please enter a positive value for the square feet of wall space to be painted: "))
            if (user_PaintArea <= 0):
                print("Zero and negative values are not allowed. Please enter a positive value.")
                continue
        except ValueError:
            print("Your input was invalid. Only numerical values are allowed.")
        else:
            break

    while(True): #Error Handling for the price of the paint per gallon
        try:
            user_PaintPrice = float(input("Please enter a positive value for the price of paint per gallon: $"))
            if (user_PaintPrice <= 0):
                print("Zero and negative values are not allowed. Please enter a positive value.")
                continue
        except ValueError:
            print("Your input was invalid. Only numerical values are allowed.")
        else:
            break

    prompt_PaintArea = 350
    charge_Labor = 62.25

    gallons_Total = user_PaintArea / prompt_PaintArea
    gallons_floorTotal = user_PaintArea // prompt_PaintArea
    if (gallons_Total > gallons_floorTotal):
        gallons_floorTotal += 1
        print("Number of gallons of paint required: %d" % gallons_floorTotal)
    else:
        print("Number of gallons of paint required: %d" % gallons_floorTotal)

    time_totalLabor = gallons_floorTotal * 6
    print("Hours of labor required: %.1f" % time_totalLabor)
    
    cost_totalPaint = gallons_floorTotal * user_PaintPrice
    print("Total cost of paint: $%.2f" % cost_totalPaint)

    cost_totalLabor = time_totalLabor * charge_Labor
    print("Total cost of labor: $%.2f" % cost_totalLabor)

    cost_paintJob = cost_totalLabor + cost_totalPaint
    print("Total cost of the paint job: $%.2f" % cost_paintJob)

    another_Estimation = input("Would you like to perform another estimation? (y/n): ")
    if (another_Estimation != 'y'):
        do_Estimation = False
        print("Thank you for using the Paint Job Estimation Program!")