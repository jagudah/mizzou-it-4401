while(True):
    try:
        f = open("randomnum.txt", "r")
    except FileNotFoundError:
        print("The file you requested doesn't exist")
    else:
        break

print("List of random numbers in randomnum.txt:")
count = 0
content = f.read(-1)
print(content)
for x in content:
    if (x == "\n"):
        count += 1

print("Random number count: %d" % count)

f.close()