import random #importing the random module

while(True): #Error Handling for total generated numbers 
    try:   
        num_Total = int(input("Please enter a positive integer for how many random numbers you want to generate: "))
        if (num_Total <= 0):
            print("Only integers greater than zero are allowed. Enter a positive integer for the total of random numbers.")
            continue
    except ValueError:
        print("Your input was invalid. Only positive integers are allowed.")
    else:
        break

while(True):
    try:
        lower_Bound = int(input("Please enter a positive integer for the lower bound: "))
        if (lower_Bound <= 0):
            print("Only integers greater than zero are allowed. Enter a positive integer for the lower bound.")
            continue
    except ValueError:
        print("Your input was invalid. Only positive integers are allowed.")
    else:
        break

while(True):
    try:
        upper_Bound = int(input("Please enter a positive integer for the upper bound: "))
        if (upper_Bound <= 0):
            print("Only integers greater than zero are allowed. Enter a positive integer for the upper bound.")
            continue
        if (upper_Bound <= lower_Bound):
            print("Upper bound must be greater than lower bound.")
            continue
    except ValueError:
        print("Your input was invalid. Only positive integers are allowed.")
    else:
        break

f = open("randomnum.txt", "w")
for x in range(num_Total):
    f.write(str(random.randint(lower_Bound, upper_Bound)))
    f.write(str("\n"))
print("Random integers were written to randomnum.txt")
f.close()