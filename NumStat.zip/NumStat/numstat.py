do_readFile = True
while(do_readFile):
    while(True):
        try:
            fname = input('Enter filename: ')
            f = open(fname, 'r')
        except FileNotFoundError:
            print("The file you requested doesn't exist.")
        else:
            print("File name: %s" % fname)
            break
    fname = f.readlines()
    count = 0
    sum = 0
    low = 999999999999999999999999999999999
    high = -999999999999999999999999999999999

    for x in fname:
        conv_int = int(x)
        sum += conv_int
        count += 1
    print("Sum: %d" % sum)
    print("Count: %d" % count)

    mean = float(sum / count)
    print("Average: %3.1f" % mean)

    for x in fname:
        if (int(x) < low):
            low = int(x)
        if (int(x) > high):
            high = int(x)
    print("Minimum: %d" % low)
    print("Maximum: %d" % high)
    range = high - low
    print("Range: %d" % range)

    another_readFile = input("Would you like to read another file? (y/n)")
    if (another_readFile != "y"):
        do_readFile = False
        print("Goodbye :)")