import Animals
import random

print("Welcome to the Animal Generation Program!")
print("This program creates Animal objects!")

animal_List = []
name_List = []
mood_List = []

do_Generation = True
while(do_Generation):
    try:
        species1 = input("""Which would you like to create?
                1. Mammal
                2. Bird
                (1/2) """)

        if (species1 != '1' and species1 != '2'):
            print("Please input '1' or '2'.")
            continue

        if (species1 == '1'):
            type1 = input("What type of mammal would you like to create? ")
            if (type1.isalpha() != True):
                print("Please use only letters of the alphabet.")
                continue

            name1 = input("What is the name of the mammal? ")
            if (name1.isalpha() != True):
                print("Please use only letters of the alphabet.")
                continue

            mood1 = ''

            hairColor1 = input("What is the mammal's hair color? ")
            if (hairColor1.isalpha() != True):
                print("Please use only letters of the alphabet.")
                continue

            myMammal = Animals.Mammal(type1, name1, mood1, hairColor1)

            name1 = myMammal.get_name()
            name_List.append(name1)

            type1 = myMammal.get_animal_type()
            animal_List.append(type1)

            mood1 = myMammal.check_mood()
            mood_List.append(mood1)

        if (species1 == '2'):
            type2 = input("What type of bird would you like to create? ")
            if (type2.isalpha() != True):
                print("Please use only letters of the alphabet.")
                continue

            name2 = input("What is the name of the mammal? ")
            if (name2.isalpha() != True):
                print("Please use only letters of the alphabet.")
                continue

            mood2 = ''

            canFly1 = input("Can the bird fly? (y/n) ")
            if (canFly1 != 'y' and canFly1 != 'n'):
                print("Please input either 'y' or 'n'.")
                continue

            myBird = Animals.Bird(type2, name2, mood2, canFly1)

            name2 = myBird.get_name()
            name_List.append(name2)

            type2 = myBird.get_animal_type()
            animal_List.append(type2)

            mood2 = myBird.check_mood()
            mood_List.append(mood2)

    except Exception as err:
        print(err)

    else:
        another_Animal = input("Would you like to add another animal? (y/n) ")
        if (another_Animal != 'y'):
           do_Generation = False
           print("\n")


print("Animal List:")
x = 0
while (x < len(mood_List)):
    print("%s the %s is %s" % (name_List[x], animal_List[x], mood_List[x]))
    x += 1