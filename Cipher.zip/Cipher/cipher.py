do_Secret = True
alpha = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
non_alpha = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '+', '<', '>', '?', '=']
space = [' ']
while(do_Secret):
    try:
        print("""Welcome to the Secret Message Encoder/Decoder
            1. Encode a message
            2. Decode a message
            3. Exit""")
        choice = input("What would you like do? (1, 2, or 3)?")

        if (choice == '1'):
            encoder = input("Enter an alphabetic message to encode: ")
            print("Encoded message: ")
            for letter in encoder:
                if letter in alpha or letter in space:
                    x = alpha.index(letter)
                    [msg_E] = non_alpha[x]
                    print(msg_E, end=" ")
            print("\n")
        
        if (choice == '2'):
            decoder = input("Enter a non-alphabetic message to decode: ")
            print("Decoded message: ")
            for letter in decoder:
                if letter in non_alpha or letter in space:
                    y = non_alpha.index(letter)
                    [msg_D] = alpha[y]
                print(msg_D, end=" ")
            print("\n")

        if (choice == '3'):
            print("Thank you for using this program! Goodbye.")
            do_Secret = False
    
    except Exception as err:
        print(err)