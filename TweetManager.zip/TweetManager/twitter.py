import Tweet as twt
import time
import pickle, io

tweet_List = []
do_tweet = True
while(do_tweet):
    try:
        print("Tweet Menu\n----------\n1. Make a Tweet\n2. View Recent Tweets\n3. Search Tweets\n4. Quit")
        
        choice = input("What would you like to do? ")

        if (choice == '1'):
            name = input("What is your name? ")
            msg = input("What would you like to tweet? ")
            if (len(msg) > 140):
                print("Tweets can only be 140 characters long!")
            else:
                myTweet = twt.Tweet(name, msg)
                tweet_List.append(myTweet)
                file = open("tweets.dat","wb")
                pickle.dump(tweet_List, file)
                file.close()
                print(name + ", your tweet has been saved!")


        elif (choice == '2'):
            file = open("tweets.dat","rb")
            tweet_List = pickle.load(file)
            file.close()
            tweet_List.reverse()
            y = 0
            print("""Recent Tweets\n------------""")
            for x in tweet_List:
                while (y < len(tweet_List) and y < 5): 
                    print("%s - %s" %(tweet_List[y].get_author(), tweet_List[y].get_age()))
                    print("%s\n" %(tweet_List[y].get_text()))
                    y += 1
            
            tweet_List.reverse()

        elif (choice == '3'):
            file = open("tweets.dat","rb")
            tweet_List = pickle.load(file)
            file.close()
            tweet_List.reverse()
            y = 0
            search = input("What would you like to search for? ")

            print("""Search Results\n-------------""")
            for x in tweet_List:
                if search in x.get_text():
                    print("%s - %s" %(x.get_author(), x.get_age()))
                    print("%s\n" %(x.get_text()))

                else:
                    y += 1
                    if y == len(tweet_List):
                        print("No tweets contained " + search + "\n")
            
            tweet_List.reverse()
        
        elif (choice == '4'):
            print("Thank you for using the Tweet Manager!")
            break

        else:
            print("Please select a valid option.\n")

    except FileNotFoundError:
        print("There are no recent tweets/tweets to search\n")