import time

class Tweet:
    def __init__(self, author, text):
        self.__author = author
        self.__text = text
        self.__age = time.time()
    
    def get_author(self):
        return self.__author
    
    def get_text(self):
        return self.__text

    def get_age(self):
        age1 = time.time()
        ageFinal = int(age1 - self.__age)
        if (ageFinal < 60):
            ageFinal //= 1
            result = str(ageFinal) + 's'
        elif (ageFinal >= 60 and ageFinal < 3600):
            ageFinal //= 60
            result = str(ageFinal) + 'm'
        elif (ageFinal >= 3600 and ageFinal < 86400):
            ageFinal //= 3600
            result = str(ageFinal) + 'h'
        elif (ageFinal >= 86400):
            ageFinal //= 86400
            result = str(ageFinal) + 'd'
        
        return result