import os

do_readFile = True
while(do_readFile):
    try:
        fname_Input = input('Enter filename: ')
        f = open(fname_Input, 'r')
        fname = f.readlines()
        Count = 0
        Sum = 0
        Low = 0
        High = 0
        fname_List = []

        for x in fname:
            fname_List.append(int(x))

        Sum = sum(fname_List)
        Count = len(fname_List)
        High = max(fname_List)
        Low = min(fname_List)
        Mean = float(Sum / Count)
        Range = High - Low

        fname_List.sort()

        # If Count is Odd
        if Count % 2 != 0:
            index_Number = int(Count // 2)
            Median = int(fname_List[index_Number])
        
        # If Count is Even
        else:
            lower_Median = int((Count // 2) - 1)
            upper_Median = int(Count // 2)
            Median = float((fname_List[lower_Median] + fname_List[upper_Median]) / 2)

        #Calculating Mode
        fname_Dict = {}
        Mode = []
        initial_Mode = 0
        for x in fname_List:
            if x in fname_Dict:
                fname_Dict[x] += 1
            else:
                fname_Dict[x] = 1
        for x in fname_Dict:
            if fname_Dict[x] == initial_Mode:
                Mode.append(int(x))
            if fname_Dict[x] > initial_Mode:
                initial_Mode = fname_Dict[x]
                Mode.clear()
                Mode.append(int(x))

        #Closing file
        f.close()

    #Exception Handling
    except ValueError:
        print("There are no values in %s" % fname_Input)
        break
    except Exception as err:
        print(err)

    #If everything goes well
    else:
        print("Filename: %s" % fname_Input)
        print("Sum: %d" % Sum)
        print("Count: %d" % Count)
        print("Average: %3.1f" % Mean)
        print("Maximum: %d" % High)
        print("Minimum: %d" % Low)
        print("Range: %d" % Range)
        print("Median: %3.1f" % Median)
        print("Mode: " + str(Mode))

        #Prompts user if they want to do another calculation
        another_readFile = input("Would you like to read another file? (y/n)")
        if (another_readFile != "y"):
            print("Goodbye :)")
            break