from turtle import Turtle

def recursive_octagons(turtle):
    turtle.pendown()
    for p in range(8):
        for s in range(8):
            turtle.right(45)
            turtle.forward(30-s)
        turtle.right(45-p)
    turtle.penup()

def main():
    Speed = 0
    Octagons = Turtle()
    Octagons.speed(Speed)
    recursive_octagons(Octagons)

main()