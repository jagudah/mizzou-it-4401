import random, pickle, io, os


stats = {
    "Name": '',
    "Won Bets": 0,
    "Money Gained": 0,
    "Lost Bets": 0,
    "Money Lost": 0,
    "Net Earnings": 0
}


def race(race_Number):
    wager = int(input("How much money are you betting (Min: $2 - Max: $1000)? $"))
    if(int(wager) < 2 or int(wager) > 1000):
            raise ValueError(print("Invalid input! Please enter an integer between 2 and 1000."))

    print("1. Secretariat\n2. Morningflame\n3. Sugar Feet\n4. Lavender\n")
    bet_Horse = input("Which horse are you betting on? ")
    if(int(bet_Horse) == 1):
        print("You bet on Secretariat. Let's get started!\n")
    
    elif(int(bet_Horse) == 2):
        print("You bet on Morningflame. Let's get started!\n")

    elif(int(bet_Horse) == 3):
        print("You bet on Sugar Feet. Let's get started!\n")

    elif(int(bet_Horse) == 4):
        print("You bet on Lavender. Let's get started!\n")
    
    else:
        raise ValueError(print("Invalid input! Please enter an integer between 1 and 4."))

    finish = 100
    speed1 = random.randint(0, 5)
    speed2 = random.randint(0, 5)
    speed3 = random.randint(0, 5)
    speed4 = random.randint(0, 5)
    horse1 = 0
    horse2 = 0
    horse3 = 0
    horse4 = 0
    print("Race %d" %race_Number)
    while(horse1 < finish and horse2 < finish and horse3 < finish and horse4 < finish):
        horse1 += speed1
        horse2 += speed2
        horse3 += speed3
        horse4 += speed4

        if(horse1 >= 100 and int(bet_Horse) == 1):
            print("Secretariat wins! You've won $%d" %(wager * 2))
            stats["Won Bets"] += 1
            stats["Money Gained"] += (wager * 2)
            stats["Net Earnings"] += (wager * 2)
            break

        elif(horse2 >= 100 and int(bet_Horse) == 2):
            print("Morningflame wins! You've won $%d" %(wager * 2))
            stats["Won Bets"] += 1
            stats["Money Gained"] += (wager * 2)
            stats["Net Earnings"] += (wager * 2)
            break

        elif(horse3 >= 100 and int(bet_Horse) == 3):
            print("Sugar Feet wins! You've won $%d" %(wager * 2))
            stats["Won Bets"] += 1
            stats["Money Gained"] += (wager * 2)
            stats["Net Earnings"] += (wager * 2)
            break

        elif(horse4 >= 100 and int(bet_Horse) == 4):
            print("Lavender wins! You've won $%d" %(wager * 2))
            stats["Won Bets"] += 1
            stats["Money Gained"] += (wager * 2)
            stats["Net Earnings"] += (wager * 2)
            break

        elif(horse1 >= 100 and int(bet_Horse) != 1):
            print("Secretariat wins! You've lost $%d" %wager)
            stats["Lost Bets"] += 1
            stats["Money Lost"] += wager
            stats["Net Earnings"] -= wager
            break

        elif(horse2 >= 100 and int(bet_Horse) != 2):
            print("Morningflame wins! You've lost $%d" %wager)
            stats["Lost Bets"] += 1
            stats["Money Lost"] += wager
            stats["Net Earnings"] -= wager
            break

        elif(horse3 >= 100 and int(bet_Horse) != 3):
            print("Sugar Feet wins! You've lost $%d" %wager)
            stats["Lost Bets"] += 1
            stats["Money Lost"] += wager
            stats["Net Earnings"] -= wager
            break

        elif(horse4 >= 100 and int(bet_Horse) != 4):
            print("Lavender wins! You've lost $%d" %wager)
            stats["Lost Bets"] += 1
            stats["Money Lost"] += wager
            stats["Net Earnings"] -= wager
            break

def post_selection(race_Number):
    do_Race = True
    while(do_Race):
        print("What would you like to do?")
        print("1. Bet Again\n2. View Betting Record\n3. Quit\n")
        post_race = input("Enter choice: ")
        
        if(post_race == '1'):
            race_Number += 1
            race(race_Number)

        elif(post_race == '2'):
            print(stats["Name"] + ", here is your betting record...")
            print("Won Bets: %d" %stats["Won Bets"])
            print("Money Gained: %d" %stats["Money Gained"])
            print("Lost Bets: %d" %stats["Lost Bets"])
            print("Money Lost: %d" %stats["Money Lost"])
            print("Net Earnings: %d" %stats["Net Earnings"])

        elif(post_race == '3'):
            record = open(stats["Name"] + ".rcd", "wb")
            if record:
                pickle.dump(stats, record)
                record.close()
                print(name + ", your betting record has been saved.")
                do_Race = False
                break

            else:
                print("Sorry %s, your betting recrod couldn't be saved." %name)
        
        else:
            raise ValueError(print("Invalid input! Please enter an integer between 1 and 3."))


print("Welcome to the Horse Race Betting Simulator!")
do_Race = True
while(do_Race):
    try:
        print("1. Place a Bet\n2. Load Betting Record\n3. Quit\n")
        pre_race = input("Which would you like to do? ")
        x = stats["Won Bets"] + stats["Lost Bets"] + 1
        if(pre_race == '1'):
            name = input("What's your name? ")
            if(name.isalpha() != True):
                raise ValueError(print("Invalid input! Please use only letters for your name.\n"))
            stats.update({"Name": name})
            race(x)
            record = open(stats["Name"] + ".rcd", "wb")
            pickle.dump(stats, record)
            record.close()
            post_selection(x)

        if(pre_race == '2'):
            name = input("What is your name? ")
            if(name.isalpha() != True):
                raise ValueError(print("Invalid input! Please use only letters for your name.\n"))
            record = open(name + ".rcd", "rb")
            if record:
                stats = pickle.load(record)
                record.close()
                x = stats["Won Bets"] + stats["Lost Bets"] + 1
                print("Welcome back %s. Let's get to betting!" %name)
                race(x)
                post_selection(x)

        if(pre_race == '3'):
            print("Thank you for using the Horse Race Betting Simulator!")
            do_Race = False

    except ValueError:
        if(int(pre_race) < 1 or int(pre_race) > 3):
            print("Invalid input! Please enter an integer between 1 and 3.\n")
        
    except FileNotFoundError:
        print("Sorry %s, your betting record does not exist.\n" %name)