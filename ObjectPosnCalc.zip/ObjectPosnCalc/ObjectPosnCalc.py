print('Welcome to the Object Final Position Calculation Program!')

print('Please enter a number for initial position: ')
x_initial = float(input())

print('Please enter a number for initial velocity: ')
v_initial = float(input())

print('Please enter a number for acceleration: ')
a = float(input())

print('Please enter a number for time: ')
t = float(input())

x_final = (x_initial + (v_initial * t) + (0.5 * a * (t**2)))

print('The final position of the object is %3.2f meters' % x_final)
print('Thank you for using the Object Final Position Calculation Program!')