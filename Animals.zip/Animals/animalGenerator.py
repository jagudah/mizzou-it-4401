import Animals
import random

print("Welcome to the Animal Generation Program!")
print("This program creates Animal objects!")

animal_List = []
name_List = []
mood_List = []

do_Generation = True
while(do_Generation):
    try:
        type1 = input("What type of animal would you like to create? ")
        if (type1.isalpha() != True):
            print("Please use only letters of the alphabet.")
            continue

        name1 = input("What is the name of the animal? ")
        if (name1.isalpha() != True):
            print("Please use only letters of the alphabet.")
            continue

        mood1 = ''

        myAnimal = Animals.Animal(type1, name1, mood1)

        name1 = myAnimal.get_name()
        name_List.append(name1)

        type1 = myAnimal.get_animal_type()
        animal_List.append(type1)

        mood1 = myAnimal.check_mood()
        mood_List.append(mood1)

    except Exception as err:
        print(err)

    else:
        another_Animal = input("Would you like to add another animal? (y/n)")
        if (another_Animal != 'y'):
           do_Generation = False
           print("\n")


print("Animal List:")
x = 0
while (x < len(mood_List)):
    print("%s the %s is %s" % (name_List[x], animal_List[x], mood_List[x]))
    x += 1