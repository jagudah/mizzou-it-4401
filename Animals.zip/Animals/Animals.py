import random

class Animal(object):

    def __init__(self, type, name, mood):
        self.__animal_type = type
        self.__name = name
        x = random.randint(1,3)
        if (x == 1):
            mood = 'happy'
        if (x == 2):
            mood = 'hungry'
        if (x == 3):
            mood = 'sleepy'
        self.__mood = mood

    def set_animal_type(self, type):
        self.__animal_type = type

    def set_name(self, name):
        self.__name = name 

    def set_mood(self, mood):
        self.__mood = mood

    def get_animal_type(self):
        return self.__animal_type

    def get_name(self):
        return self.__name

    def check_mood(self):
        return self.__mood